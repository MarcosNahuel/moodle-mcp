<?php
defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_italiciamcp_upsert_page' => [
        'classname'    => 'local_italiciamcp\\external\\upsert_page',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_page in a course section, keyed by a stable idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_italiciamcp_delete_module_by_idnumber' => [
        'classname'    => 'local_italiciamcp\\external\\delete_module_by_idnumber',
        'methodname'   => 'execute',
        'description'  => 'Delete a course module identified by its idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_italiciamcp_update_course_summary' => [
        'classname'    => 'local_italiciamcp\\external\\update_course_summary',
        'methodname'   => 'execute',
        'description'  => 'Update the summary (description) of a course',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    'local_italiciamcp_upsert_quiz' => [
        'classname'    => 'local_italiciamcp\\external\\upsert_quiz',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_quiz shell (no questions), keyed by idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
];
